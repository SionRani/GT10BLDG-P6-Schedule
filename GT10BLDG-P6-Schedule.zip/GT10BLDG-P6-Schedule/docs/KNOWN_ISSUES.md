# Known issues (checked against the export, 21-Sep-2026)

1. **SUP-F9-06 -> SUP-F10-01 is Finish-to-Finish (FF).** Should be FS, lag 0. Fix in P6 (Predecessors tab), press F9, then update the baseline.
2. **MAS-F10-01 -> MAS-F10-02 has lag 0.** All other floors use FS +3d. Set lag to 3.
3. **Original input list vs P6:** MEP-x-02 links are FS in P6 (input list says SS), and PRE-020 -> PRE-030 is FS (input list says SS). Both are intentional simplifications.
4. `SUB -010` (space in ID) and `HO-030A1000` may still appear in older exports; the latest P6 view shows `SUB-010` and `HO-030`.
5. Baseline was saved before fixing items 1 and 2. Use Maintain Baselines > Update afterwards.
6. Durations to verify against the input list: SUP-F1-05 (1d), SUP-F1-06 (2d), SUP-F6-02 (1d), SUP-F6-03 (4d).
