"""Builds Gantt chart images/PDF from the P6 export (exports/GT10BLDG_v1_P6_export.xlsx)."""
import pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
import warnings; warnings.filterwarnings("ignore")

F = "exports/GT10BLDG_v1_P6_export.xlsx"
t = pd.read_excel(F, "TASK").iloc[1:].copy()
t["s"] = pd.to_datetime(t.start_date); t["e"] = pd.to_datetime(t.end_date)

def phase(c):
    for k, n in [("PRE","1 Preliminary & Mobilization"),("SUB","2 Substructure"),("SUP","3 Superstructure (GF-F10)"),
                 ("MAS","4 Masonry & Plastering"),("MEP","5 MEP Works"),("FIN","6 Finishing Works"),("HO","7 Handover & Testing")]:
        if c.startswith(k): return n
t["phase"] = t.task_code.map(phase)
COL = dict(zip(sorted(t.phase.unique()), ["#4c78a8","#f58518","#54a24b","#b279a2","#e45756","#72b7b2","#9d755d"]))

def draw(ax, d, fs=6):
    d = d.reset_index(drop=True)
    for i, r in d.iterrows():
        ax.barh(i, (r.e - r.s).days + 1, left=mdates.date2num(r.s), color=COL[r.phase], height=.7)
    ax.set_yticks(range(len(d))); ax.set_yticklabels(d.task_code + "  " + d.task_name.str[:32], fontsize=fs)
    ax.invert_yaxis(); ax.xaxis_date()
    ax.xaxis.set_major_locator(mdates.MonthLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))
    ax.tick_params(axis="x", labelsize=7, rotation=90); ax.grid(axis="x", ls=":", alpha=.5)
    ax.set_xlim(mdates.date2num(t.s.min()) - 5, mdates.date2num(t.e.max()) + 5)

start, fin = t.s.min().strftime("%d-%b-%Y"), t.e.max().strftime("%d-%b-%Y")
with PdfPages("images/GT10BLDG_Gantt.pdf") as pdf:
    # page 1: phase summary
    g = t.groupby("phase").agg(s=("s","min"), e=("e","max")).reset_index()
    g["task_code"] = g.phase.str[:1]; g["task_name"] = g.phase.str[2:]
    fig, ax = plt.subplots(figsize=(16.5, 6))
    draw(ax, g.rename(columns={}), 9)
    for i, r in g.iterrows():
        ax.text(mdates.date2num(r.e) + 4, i, r.e.strftime("%d-%b-%y"), va="center", fontsize=8)
    fig.suptitle(f"GT10BLDG - G+10 Residential Building: Summary Schedule\n{start} to {fin}", fontsize=13)
    fig.tight_layout(); pdf.savefig(fig); fig.savefig("images/GT10BLDG_Gantt_summary.png", dpi=150); plt.close(fig)
    # detailed pages: ~45 activities per page
    d = t.sort_values(["s","task_code"]).reset_index(drop=True); n = 45
    for k in range(0, len(d), n):
        fig, ax = plt.subplots(figsize=(16.5, 11.7))
        draw(ax, d.iloc[k:k+n])
        ax.legend(handles=[plt.Rectangle((0,0),1,1,color=c) for c in COL.values()], labels=list(COL), fontsize=7, loc="lower left")
        fig.suptitle(f"GT10BLDG Detailed Gantt (sorted by start) - page {k//n+1}", fontsize=12)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)
print(start, fin, len(t))
