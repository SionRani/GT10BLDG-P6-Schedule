# GT10BLDG - Construction of G+10 Residential Building (Primavera P6)

Construction schedule for a G+10 residential building, built in **Oracle Primavera P6 Professional 25**.

![Summary Gantt](images/GT10BLDG_Gantt_summary.png)

## Project summary
| Item | Value |
|---|---|
| Project ID | GT10BLDG |
| Start / Data Date | 01-Oct-2026 |
| Finish | 04-Feb-2028 (about 16 months) |
| Activities | 140 |
| Relationships | 176 (FS with lags, SS, one FF - see known issues) |
| Calendar | 6-Day Week |
| Baseline | Baseline 1 - Original Plan (Initial Planning Baseline) |

## Work breakdown
| WBS | Phase | Activity prefix |
|---|---|---|
| 1 | Preliminary & Mobilization | PRE |
| 2 | Substructure & Superstructure (excavation, footing, GF to F10 structure) | SUB, SUP |
| 3 | Masonry & Plastering | MAS |
| 4 | MEP Works (electrical, plumbing, HVAC / fire fighting) | MEP |
| 5 | Finishing Works (flooring, painting, doors / windows) | FIN |
| 6 | Handover & Testing | HO |

## Key logic
- Floor cycle: column reinforcement, column concreting, slab shuttering (+1d), slab reinforcement (SS +2d), slab concreting, de-shuttering (+7d curing), then the next floor.
- Masonry starts 5 days after de-shuttering. Plastering follows block work (+3d). Flooring follows plastering (+5d) and MEP rough-in.

## Repository layout
```
schedule/   P6 project file (.xer) - add your XER export here
exports/    GT10BLDG_v1_P6_export.xlsx (TASK and TASKPRED sheets from P6)
source/     Original input list (activities, relationships) used to build the schedule
images/     Gantt chart PDF and summary PNG
docs/       Notes and known issues
make_gantt.py   Regenerates the Gantt PDF/PNG from the export
```

## Regenerate the Gantt chart
```
pip install pandas openpyxl matplotlib
python make_gantt.py
```

## Version history
| Version | Date | Notes |
|---|---|---|
| v1 | 21-Sep-2026 | Logic, lags, baseline saved |
